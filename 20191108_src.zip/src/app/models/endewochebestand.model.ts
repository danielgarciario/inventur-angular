export interface EndeWocheBestand {
  cwar: string;
  item: string;
  cuni: string;
  jahr_kw: number;
  kw: number;
  menge: number;
}
