export interface LagerBestand {
  qhnd: number;
  qord: number;
  qblk: number;
  qall: number;
  disponible: number;
}
