export interface Urf {
  un: string;
  ununidad: string;
  cuantos: number;
  desstos: string;
  unidadalmacen: string;
}
