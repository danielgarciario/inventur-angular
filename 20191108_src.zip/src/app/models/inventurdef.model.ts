export interface InventurDef {
  idinventur: number;
  inventur: string;
}
