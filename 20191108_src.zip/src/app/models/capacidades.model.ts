import { LagerOrt } from './lagerort.model';

export interface Capacidades {
  lagerort: LagerOrt;
  maxbtnd: number;
}
