export interface Lager {
  cwar: string;
  lager: string;
}
