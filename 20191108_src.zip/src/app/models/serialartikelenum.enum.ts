export enum SerialArtikelEnum {
  Ja = 1,
  Nein = 2
}
