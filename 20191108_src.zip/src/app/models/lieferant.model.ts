export interface Lieferant {
  liefnr: string;
  liefname: string;
}
