export interface User {
  emno: string;
  login: string;
  password: string;
  name: string;
  token: string;
}
