import { LagerOrt } from './lagerort.model';

export interface FestLagerPLatz {
  prioridad: number;
  lagerort: LagerOrt;
}
