export enum Artikelartenum {
  EKArtikel = 1,
  FertigungsArtikel = 2,
  GenerellerArtikel = 3,
  KostenArtikel = 4,
  ServiceArtikel = 5,
  FrendvergebeneArtikel = 6,
  Mehrkomponentenartikel = 10,
  Einsatzmittel = 15,
  Konstriktionsbaugruppe = 20
}
